
package com.shivsales.stock

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

data class Product(var name:String,var purchase:Double,var sell:Double,var stock:Int,var min:Int)

class MainActivity: Activity() {
    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("stock",0) }
    private val products = mutableListOf<Product>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); load(); build()
    }
    private fun load() {
        val a=JSONArray(prefs.getString("products","[]"))
        for(i in 0 until a.length()){val o=a.getJSONObject(i);products.add(Product(o.getString("name"),o.getDouble("purchase"),o.getDouble("sell"),o.getInt("stock"),o.getInt("min")))}
    }
    private fun save(){
        val a=JSONArray(); products.forEach{p->a.put(JSONObject().apply{put("name",p.name);put("purchase",p.purchase);put("sell",p.sell);put("stock",p.stock);put("min",p.min)})}
        prefs.edit().putString("products",a.toString()).apply()
    }
    private fun build(){
        val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setPadding(24,24,24,24)
        val title=TextView(this);title.text="Shiv Sales Stock Manager";title.textSize=24f;title.setTextColor(Color.rgb(20,80,150));root.addView(title)
        val buttons=LinearLayout(this);buttons.orientation=LinearLayout.HORIZONTAL
        fun btn(t:String, f:()->Unit):Button{val b=Button(this);b.text=t;b.setOnClickListener{f()};buttons.addView(b,LinearLayout.LayoutParams(0,WRAP,1f));return b}
        btn("Add Product"){addProduct()}
        btn("Stock In"){stockChange(true)}
        btn("Stock Out"){stockChange(false)}
        root.addView(buttons)
        val summary=TextView(this);summary.id=100;summary.textSize=16f;root.addView(summary)
        val scroll=ScrollView(this);list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL;scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root);refresh(summary)
    }
    private fun refresh(summary:TextView){
        summary.text="Products: ${products.size}   |   Total units: ${products.sumOf{it.stock}}"
        list.removeAllViews()
        products.forEachIndexed{idx,p->
            val tv=TextView(this);tv.text="${p.name}\nStock: ${p.stock}  |  Buy ₹${p.purchase}  |  Sell ₹${p.sell}"+if(p.stock<=p.min)"\n⚠ LOW STOCK" else "";tv.textSize=17f;tv.setPadding(12,18,12,18)
            tv.setOnClickListener{editProduct(idx)}
            list.addView(tv)
        }
    }
    private fun addProduct(){ productDialog(null) }
    private fun editProduct(i:Int){ productDialog(i) }
    private fun productDialog(index:Int?){
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL
        fun e(h:String,v:String=""):EditText{val x=EditText(this);x.hint=h;x.setText(v);box.addView(x);return x}
        val p=index?.let{products[it]}
        val n=e("Product name",p?.name?:"");val buy=e("Purchase price",p?.purchase?.toString()?:"");val sell=e("Selling price",p?.sell?.toString()?:"");val st=e("Stock quantity",p?.stock?.toString()?:"0");val min=e("Minimum stock alert",p?.min?.toString()?:"10")
        AlertDialog.Builder(this).setTitle(if(index==null)"Add Product" else "Edit Product").setView(box).setPositiveButton("Save"){_,_->
            val np=Product(n.text.toString(),buy.text.toString().toDoubleOrNull()?:0.0,sell.text.toString().toDoubleOrNull()?:0.0,st.text.toString().toIntOrNull()?:0,min.text.toString().toIntOrNull()?:10)
            if(index==null)products.add(np) else products[index]=np;save();build()
        }.setNegativeButton("Cancel",null).show()
    }
    private fun stockChange(incoming:Boolean){
        if(products.isEmpty()){Toast.makeText(this,"Add a product first",Toast.LENGTH_SHORT).show();return}
        val names=products.map{it.name}.toTypedArray()
        var selected=0
        val qty=EditText(this);qty.hint="Quantity";qty.inputType=2
        AlertDialog.Builder(this).setTitle(if(incoming)"Stock In" else "Stock Out").setSingleChoiceItems(names,0){_,w->selected=w}.setView(qty)
        .setPositiveButton("Save"){_,_->val q=qty.text.toString().toIntOrNull()?:0;if(q>0){products[selected].stock += if(incoming)q else -q; if(products[selected].stock<0)products[selected].stock=0;save();build()}}
        .setNegativeButton("Cancel",null).show()
    }
    companion object{const val WRAP=LinearLayout.LayoutParams.WRAP_CONTENT}
}
