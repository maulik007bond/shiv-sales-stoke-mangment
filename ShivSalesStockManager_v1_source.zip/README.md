# Shiv Sales Stock Manager v1
Android stock-management app for Shiv Sales.

Features:
- Add/edit products
- Purchase and selling prices
- Stock In / Stock Out
- Low-stock alerts
- Offline local storage
- Product list and total-unit dashboard

Example products can be added: Viner Soap, Sayra Soap, Woman Touch Premium Sanitary Pad, Protect Sanitary Pad, Honey Bunny Diapers.

Build with Android Studio using the included Gradle project.
